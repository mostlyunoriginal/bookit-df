"""PDF rendering for codebooks."""
